-- Progression : tableaux débloqués par le score, trophées, code secret, défi final
local P = {}
P.TROPHIES = {
  {"Player One","Finir sa premiere partie","F"},{"Sesame, ouvre-toi","Ouvrir un cadenas","F"},
  {"Tarzan junior","Atteindre 100 points","F"},{"100 % Bonus","Atteindre 200 points","F"},
  {"Hakuna Coco-ta","5 noix de coco dans une partie","F"},{"Les Oiseaux... mais en pire","3 oiseaux elimines dans une partie","F"},
  {"Le Grand Bleu","Tomber a l'eau","F"},{"Mary Poppins","5 parapluies dans une partie","F"},
  {"La-haut, la-haut","5 ballons dans une partie","F"},{"Retour vers le futur","Jouer avec 5 graphismes","F"},
  {"La Grande Evasion","4 cadenas dans la meme partie","M"},{"This is Sparta... euh, 300 !","Atteindre 300 points","M"},
  {"Sans peur et sans reproche","300 points sans MISS","M"},{"Mode Hardcore","300 points en Game B","M"},
  {"Double gagnant","2 oiseaux, meme noix de coco","M"},{"Le Cueilleur du Seigneur","150 noix de coco au total","M"},
  {"Les Quatre Saisons de Junior","Debloquer les 4 saisons","M"},{"Never Ending Story","15 minutes dans une partie","M"},
  {"Alerte a Malibu","25 chutes dans l'eau au total","M"},{"Amadeus","200 pts ou plus avec le son symphonique","M"},
  {"Top Gun","Parapluie du bas puis ballon","M"},{"Terminator des piafs","3 oiseaux, meme noix de coco","D"},
  {"Le Cote obscur","Debloquer le Monde Dark","D"},{"E.T. telephone maison","Voir la vraie fin du jeu","D"},
  {"Highlander","Atteindre 999 points","D"},{"Intouchables","600 points sans MISS","D"},
  {"Les Dents de la mer","500 points en Game B","D"},{"Volcano","400 points en Monde Dark","D"},
  {"Flash Gordon","2 cadenas a moins de 8 s d'ecart","D"},{"Gotta catch 'em all","Tous les autres trophees","D"},
  {"Coup de main","Code secret de la noix de coco","S"},
}
P.ORDER = { "orig", "hd", "lcdhd", "automne", "halloween", "hiver", "noel", "dark" }
P.AT = { orig = 0, hd = 0, lcdhd = 0, automne = 150, halloween = 300, hiver = 450, noel = 600, dark = 800 }
P.final = false
local S = { best = 0, earned = {}, code = false, bits = {}, cocos = 0, falls = 0, used = {}, top = {} }
local say = print
local function save()
  local t = { "best=" .. S.best, "code=" .. (S.code and 1 or 0), "v=2", "cocos=" .. S.cocos, "falls=" .. S.falls }
  local e, b, u = {}, {}, {}
  for k in pairs(S.earned) do e[#e + 1] = k end; for k in pairs(S.bits) do b[#b + 1] = k end; for k in pairs(S.used) do u[#u + 1] = k end
  local tp = {}; for _, r in ipairs(S.top) do tp[#tp + 1] = r.s .. ":" .. r.m .. ":" .. r.k .. ":" .. r.d end
  t[#t + 1] = "top=" .. table.concat(tp, ";")
  t[#t + 1] = "earned=" .. table.concat(e, ","); t[#t + 1] = "bits=" .. table.concat(b, ","); t[#t + 1] = "used=" .. table.concat(u, ",")
  love.filesystem.write("progress.txt", table.concat(t, "\n") .. "\n")
end
function P.load(sayfn)
  say = sayfn
  local s = love.filesystem.read("progress.txt"); if not s then return end
  for k, v in s:gmatch("(%w+)=([^\n]*)") do
    if k == "best" or k == "cocos" or k == "falls" then S[k] = tonumber(v) or 0
    elseif k == "code" then S.code = v == "1"
    elseif k == "v" then S.v = tonumber(v)
    elseif k == "top" then for sc, m, kk, d in v:gmatch("(%d+):(%a):(%d+):([^;]*)") do S.top[#S.top + 1] = { s = tonumber(sc), m = m, k = tonumber(kk), d = d } end
    else for w in v:gmatch("[^,]+") do if k == "bits" then S.bits[tonumber(w)] = true elseif k == "earned" then S.earned[w] = true elseif k == "used" then S.used[w] = true end end end
  end
end
-- v2 : l'ancien code secret se declenchait par accident -> remis a zero une fois
local _load = P.load
function P.load(sayfn) _load(sayfn); if S.v ~= 2 then S.code = false; S.v = 2; save() end end
function P.unlocked(sk) return S.code or P.AT[sk] == 0 or S.earned[sk] == true end
function P.has(i) return S.bits[i] == true end
function P.count() local n = 0; for _ in pairs(S.bits) do n = n + 1 end; return n end
-- notifications de trophées (file d'attente)
P.queue = {}; P.cur = nil; P.curT = 0
local gameBits = {}
function P.award(i)
  if P.final then return end
  gameBits[i] = true
  if S.bits[i] then return end
  S.bits[i] = true; save(); P.queue[#P.queue + 1] = i
  local all = true; for k = 0, 28 do if not S.bits[k] then all = false end end
  if all then P.award(29) end
end
function P.usedSkin(sk) if not S.used[sk] then S.used[sk] = true; save() end local n = 0; for _ in pairs(S.used) do n = n + 1 end; if n >= 5 then P.award(9) end end
local function earn(score)
  if P.final then return end
  for _, sk in ipairs(P.ORDER) do
    if P.AT[sk] > 0 and score >= P.AT[sk] and not S.earned[sk] then
      S.earned[sk] = true; save(); if not S.code then say("Nouveau tableau : " .. sk .. " (L1)") end
    end
  end
  if S.earned.automne and S.earned.halloween and S.earned.hiver and S.earned.noel then P.award(16) end
  if S.earned.dark then P.award(22) end
end
-- lecture de l'écran
local function I(t) local x, y, z = t:match("(%d+)%.(%d+)%.(%d+)"); return tonumber(x) * 64 + tonumber(y) * 4 + tonumber(z) end
local SEG7 = { [0x3f] = 0, [0x06] = 1, [0x5b] = 2, [0x4f] = 3, [0x66] = 4, [0x6d] = 5, [0x7d] = 6, [0x07] = 7, [0x7f] = 8, [0x6f] = 9, [0x27] = 7, [0x7c] = 6, [0x67] = 9 }
local SEGV = { [0] = 0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07, 0x7f, 0x6f }
local function dsegs(col) return { 64 + col * 4, 64 + col * 4 + 1, 64 + col * 4 + 2, col * 4 + 3, col * 4 + 2, col * 4, col * 4 + 1 } end
local COLON = I("0.8.2")
function P.readScore(seg)
  if seg[COLON] == 1 then return -1 end
  local v = 0
  for _, col in ipairs({ 5, 6, 7 }) do
    local m = 0; for i, s in ipairs(dsegs(col)) do if seg[s] == 1 then m = m + 2 ^ (i - 1) end end
    local d = (m == 0) and 0 or SEG7[m]; if d == nil then return -1 end; v = v * 10 + d
  end
  return v
end
function P.applyOffset(seg, off)        -- défi final : le score affiché = score réel + 980
  if seg[COLON] == 1 then return end
  local v, any = 0, false
  for _, col in ipairs({ 5, 6, 7 }) do
    local m = 0; for i, s in ipairs(dsegs(col)) do if seg[s] == 1 then m = m + 2 ^ (i - 1) end end
    if m > 0 then any = true end; v = v * 10 + ((SEG7[m] or 0))
  end
  if not any then return end
  local sh = math.min(999, v + off); local ds = { math.floor(sh / 100), math.floor(sh / 10) % 10, sh % 10 }
  for k, col in ipairs({ 5, 6, 7 }) do local m = SEGV[ds[k]]; for i, s in ipairs(dsegs(col)) do seg[s] = (math.floor(m / 2 ^ (i - 1)) % 2) end end
end
local function on(seg, t) return seg[I(t)] == 1 end
local function any(seg, list) for _, t in ipairs(list) do if seg[I(t)] == 1 then return true end end return false end
local MISS_T = { "1.10.3", "0.10.3", "1.9.3" }
local LOCK_T = { "1.9.1", "0.9.1", "0.8.3", "1.8.3" }
local COCO_FALL = { "0.15.3", "0.15.1", "1.14.0", "1.0.1", "0.0.2" }
local SPLASH_T = { "1.3.2", "0.3.2" }
P.UMB_T = { "0.12.2", "0.12.1", "1.12.0", "0.3.0" }
local BAL_T = { "0.11.2", "1.11.0", "0.11.0", "0.4.1" }
local function edge() return { v = false, cand = false, since = 0 } end
local function stable(e, raw, now, ms)
  if raw ~= e.cand then e.cand = raw; e.since = now end
  if e.cand ~= e.v and now - e.since >= ms / 1000 then e.v = e.cand; return e.v and "up" or "down" end
end
local G = nil
P.armed = false
function P.newGame(mode, seg)
  local now = love.timer.getTime()
  G = { mode = mode, t0 = now, last = P.readScore(seg), max = 0, missMax = 0, locks = 0, lastLock = -1e9, lockE = {},
        cocoE = edge(), splashE = edge(), umbE = edge(), balE = edge(), handE = edge(), keyOff = 0,
        falling = false, kills = 0, cocos = 0, birds = 0, umbs = 0, bals = 0, umbBottom = -1e9, missAtUmb = 0, hits = 0, lastHit = -1e9, over = false }
  for k, t in ipairs(LOCK_T) do local v = on(seg, t); G.lockE[k] = { v = v, cand = v, since = now } end
  gameBits = {}; P.armed = false
end
-- appelé ~60 fois / s ; renvoie "over" en fin de partie, "ending" quand la vraie fin doit démarrer
function P.update(seg, skin, sym)
  local playing = (seg[COLON] ~= 1) and (on(seg, "1.4.2") or on(seg, "1.3.0"))
  if not playing then G = nil; return end
  local mode = on(seg, "1.3.0") and "B" or "A"
  local miss = 0; for _, t in ipairs(MISS_T) do if on(seg, t) then miss = miss + 1 end end
  local sc, now = P.readScore(seg), love.timer.getTime()
  if not G or (G.over and miss == 0 and sc == 0) then P.newGame(mode, seg) end
  if G.over then return end
  if miss > G.missMax then G.missMax = miss end
  if sc >= 0 and sc ~= G.last then
    local inc = (sc > G.last and sc - G.last < 20) and (sc - G.last) or 0
    if inc > 0 and G.falling then G.kills = G.kills + 1; G.birds = G.birds + 1
      if G.birds >= 3 then P.award(5) end; if G.kills >= 2 then P.award(14) end; if G.kills >= 3 then P.award(21) end end
    G.last = sc; if sc > G.max then G.max = sc end
    if sc >= 100 then P.award(2) end; if sc >= 200 then P.award(3) end; if sc >= 300 then P.award(11) end; if sc >= 999 then P.award(24) end
    if G.missMax == 0 and sc >= 300 then P.award(12) end; if G.missMax == 0 and sc >= 600 then P.award(25) end
    if G.mode == "B" and sc >= 300 then P.award(13) end; if G.mode == "B" and sc >= 500 then P.award(26) end
    if sc >= 400 and skin == "dark" then P.award(27) end
    if sc > S.best and not P.final then S.best = sc; save() end
    earn(sc)
  end
  for k, t in ipairs(LOCK_T) do if stable(G.lockE[k], on(seg, t), now, 1200) == "down" then
    G.locks = G.locks + 1; P.award(1); if G.locks >= 4 then P.award(10) end
    if now - G.lastLock < 8 then P.award(28) end; G.lastLock = now end end
  local falling = any(seg, COCO_FALL)
  if stable(G.cocoE, on(seg, COCO_FALL[1]), now, 60) == "up" then G.kills = 0; G.cocos = G.cocos + 1
    if not P.final then S.cocos = S.cocos + 1; save() end
    if G.cocos >= 5 then P.award(4) end; if S.cocos >= 150 then P.award(15) end end
  G.falling = falling
  -- code secret : 10 gestes de la main d'affilee, rapides (< 1,5 s), sans point ni MISS entre les gestes
  if stable(G.handE, on(seg, "1.15.3"), now, 30) == "up" then
    local miss = 0; for _, m in ipairs({ "1.10.3", "0.10.3", "1.9.3" }) do if on(seg, m) then miss = miss + 1 end end
    local keep = (now - G.lastHit < 1.5) and sc == G.hitScore and miss == G.hitMiss
    G.hits = keep and (G.hits + 1) or 1; G.lastHit = now; G.hitScore = sc; G.hitMiss = miss
    if G.hits >= 10 then G.hits = 0
      if not S.code then S.code = true; save(); say("CODE SECRET : tous les tableaux sont debloques !") end
      if not S.bits[30] then S.bits[30] = true; save(); P.queue[#P.queue + 1] = 30 end end end
  if stable(G.splashE, any(seg, SPLASH_T), now, 80) == "up" then if not P.final then S.falls = S.falls + 1; save() end; P.award(6); if S.falls >= 25 then P.award(18) end end
  if stable(G.umbE, any(seg, P.UMB_T), now, 120) == "up" then G.umbs = G.umbs + 1; if G.umbs >= 5 then P.award(7) end
    if P.armed and sc >= 980 and skin == "dark" then return "ending" end end
  if on(seg, "0.3.0") then G.umbBottom = now; G.missAtUmb = miss end
  if stable(G.balE, any(seg, BAL_T), now, 120) == "up" then G.bals = G.bals + 1; if G.bals >= 5 then P.award(8) end
    if now - G.umbBottom < 2.5 and miss <= G.missAtUmb then P.award(20) end end
  -- lance-pierre récupéré (il quitte son crochet plus d'une seconde) à 980 points
  if sc >= 980 then
    if on(seg, "2.1.1") then G.keyOff = 0 else G.keyOff = G.keyOff + 1 / 60 end
    if G.keyOff > 0.9 and not P.armed then P.armed = true; say("Lance-pierre recupere ! Attrape un parapluie...") end
  end
  if now - G.t0 > 900 then P.award(17) end
  if miss >= 3 then G.over = true; P.award(0); if sym and math.max(G.max, G.last) >= 200 then P.award(19) end; return "over" end
end
function P.realEnding() if not P.final then P.award(23) end end
-- ===== fin de partie : classement local + code / QR pour le classement en ligne =====
P.LB = "https://script.google.com/macros/s/AKfycbw8GbvZPC9u3aHtns4gz4IxT0NCboVbmfBt3z1bDgiLWT-y_nLNNNSEnHIJGv8CxMMAUw/exec"
local SALT = "dkjr-panorama-cj93"
local function u32(x) return x % 4294967296 end
local function fnv(str)            -- FNV-1a 32 bits, identique au jeu PC et au script Google
  local h = 2166136261
  for i = 1, #str do
    h = u32(bit.bxor(h, str:byte(i)))
    h = u32(h * 403 + (h % 256) * 16777216)
  end
  return string.format("%08x", h)
end
function P.encode(score, mode, skinIdx, bitsMask, day)
  local body = table.concat({ "r1", string.format("%03d", math.max(0, math.min(999, score))), mode == "B" and "b" or "a",
    string.format("%x", skinIdx), string.format("%08x", bitsMask), string.format("%03x", day) }, "-")
  return body .. "-" .. fnv(body .. SALT)
end
function P.gameMask() local m = 0; for i in pairs(gameBits) do m = m + 2 ^ i end; return m end
function P.gameCount() local n = 0; for _ in pairs(gameBits) do n = n + 1 end; return n end
function P.top() return S.top end
-- appelé quand la partie est finie : renvoie le score, le code et l'adresse à mettre dans le QR code
function P.finish(skin)
  local score, mode = G and math.max(G.last or 0, 0) or 0, G and G.mode or "A"
  local k = 0; for j, n in ipairs(P.ORDER) do if n == skin then k = j - 1 end end
  local day = math.max(0, math.floor((os.time() - os.time({ year = 2026, month = 1, day = 1, hour = 0 })) / 86400))
  local code = P.encode(score, mode, k, P.gameMask(), day)
  table.insert(S.top, { s = score, m = mode, k = k, d = os.date("%d/%m/%Y") })
  table.sort(S.top, function(a, b) return a.s > b.s end)
  while #S.top > 10 do table.remove(S.top) end
  save()
  return { score = score, mode = mode, skin = k, code = code, url = P.LB .. "?partie=" .. code, n = P.gameCount() }
end
P.SKIN_NAMES = { "Original", "Remake HD", "Origine embellie", "Automne", "Halloween", "Hiver", "Noel", "Monde Dark" }
return P
