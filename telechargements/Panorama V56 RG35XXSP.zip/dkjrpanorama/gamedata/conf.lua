function love.conf(t)
  t.identity = "dkjrpanorama"
  t.version = "11.5"
  t.window.title = "DK Jr. Panorama"
  t.window.width = 640
  t.window.height = 480
  t.window.fullscreen = true
  t.window.vsync = 1
  t.modules.physics = false
  t.modules.video = true
end
