-- Émulateur SM511 (Sharp) — même cœur que la version PC (gameplay identique)
local bit = require("bit")
local band, bor, bxor, lshift, rshift = bit.band, bit.bor, bit.bxor, bit.lshift, bit.rshift

local M = {}
M.__index = M

local LUT = {
  [0]=0,0,7,8,8,9,9,10,11,11,12,13,14,14,0,0,
  0,0,7,7,8,9,9,10,10,11,12,13,13,14,0,0,
  0,0,7,8,8,9,10,10,11,12,12,13,14,15,0,0,
  0,0,7,8,8,9,9,10,11,11,12,13,14,14,0,0,
}
M.LUT = LUT

function M.new(romStr, melStr)
  local c = setmetatable({}, M)
  c.rom, c.mel = {}, {}
  for i = 0, #romStr - 1 do c.rom[i] = romStr:byte(i + 1) end
  for i = 0, 255 do c.mel[i] = melStr:byte(i + 1) or 0 end
  c.ram = {}; for i = 0, 127 do c.ram[i] = 0 end
  c.stack = { 0, 0 }
  c.inputs = {}; for i = 0, 7 do c.inputs[i] = 0 end
  c.ba, c.b = 1, 1
  c.div, c.tickCount = 0, 0
  c.melAddr, c.melStep, c.melDutyCount, c.melDutyIdx, c.melRd = 0, 0, 0, 0, 0
  c.r = 0; c.owed = 0
  c:reset()
  return c
end

function M:reset()
  self.skip = false; self.halt = false; self.sbm = false
  self.op = 0; self.prevOp = 0
  self.acc = 0; self.bl = 0; self.bm = 0; self.c = 0
  self.w = 0; self.s = 0
  self.pc = 0xdc0; self.prevPc = self.pc
  self.bp = 1; self.bc = 0; self.y = 0; self.l = 0; self.x = 0
  self.r = 0; self.melRd = band(self.melRd, 2)
  self.clkDiv = 2; self.k1s = false
end

function M:incPc()
  local pc = self.pc
  local feed = (band(bxor(rshift(pc, 1), pc), 1) ~= 0) and 0 or 0x20
  self.pc = bor(feed, band(rshift(pc, 1), 0x1f), band(pc, 0xfc0))
end

function M:addr() return band(bor(self.sbm and 0x40 or 0, lshift(self.bm, 4), self.bl), 0x7f) end
function M:ramR() return band(self.ram[self:addr()], 0xf) end
function M:ramW(v) self.ram[self:addr()] = band(v, 0xf) end
function M:branch(pu, pm, pl) self.pc = band(bor(lshift(pu, 10), band(lshift(pm, 6), 0x3c0), band(pl, 0x3f)), 0xfff) end
function M:push() self.stack[2] = self.stack[1]; self.stack[1] = self.pc end
function M:pop() self.pc = band(self.stack[1], 0xfff); self.stack[1] = self.stack[2] end
function M:readK()
  local d = 0
  for i = 0, 7 do if band(rshift(self.s, i), 1) == 1 then d = bor(d, self.inputs[i]) end end
  return band(d, 0xf)
end
function M:fetch() local v = self.rom[self.pc] or 0; self:incPc(); return v end
function M:incb() self.bl = band(self.bl + 1, 0xf); self.skip = (self.bl == 0) end
function M:decb() self.bl = band(self.bl - 1, 0xf); self.skip = (self.bl == 0xf) end
function M:exc(op) local a = self.acc; self.acc = self:ramR(); self:ramW(a); self.bm = bxor(self.bm, band(op, 3)) end

-- un tick d'horloge à 32 768 Hz : diviseur + mélodie
function M:clockTick()
  self.tickCount = self.tickCount + 1
  self.div = band(self.div + 1, 0x7fff)
  if self.div == 0 then self.k1s = true end
  local cmd = band(self.mel[band(self.melAddr, 0xff)], 0x3f)
  local t = band(cmd, 0xf)
  local out = 0
  if t > 1 then
    out = band(self.melDutyIdx, self.melRd, 1)
    self.melDutyCount = self.melDutyCount + 1
    local idx = bor(lshift(self.melDutyIdx, 4), t)
    local sh = band(rshift(bit.bnot(cmd), 4), 1)
    if self.melDutyCount >= lshift(LUT[idx], sh) then
      self.melDutyCount = 0; self.melDutyIdx = band(self.melDutyIdx + 1, 3)
    end
  elseif t == 1 then self.melRd = bor(self.melRd, 2) end
  if band(self.div, 0x7f) == 0 then
    local mask = (band(cmd, 0x20) ~= 0) and 0x1f or 0x0f
    self.melStep = band(self.melStep + 1, mask)
    if self.melStep == 0 then self.melAddr = band(self.melAddr + 1, 0xff) end
  end
  self.r = out
end

-- exécute une instruction, renvoie le nombre de ticks qu'elle consomme
function M:step()
  if self.halt then
    if self.k1s or self:readK() ~= 0 then self.halt = false; self:branch(1, 0, 0)
    else return self.clkDiv end
  end
  self.prevOp = self.op; self.prevPc = self.pc
  local op = self:fetch(); self.op = op
  local cyc = 1
  if (op >= 0x5f and op <= 0x61) or band(op, 0xf0) == 0x70 or band(op, 0xfc) == 0x68 then
    self.param = self:fetch(); cyc = cyc + 1
  end
  if self.skip then self.skip = false; self.op = 0
  else cyc = cyc + self:exec(op) end
  self.sbm = (self.op == 0x02)
  return cyc * self.clkDiv
end

-- avance d'un tick (1 tick = 1 échantillon audio à 32 768 Hz)
function M:tick()
  while self.owed <= 0 do self.owed = self.owed + self:step() end
  self:clockTick(); self.owed = self.owed - 1
end

function M:exec(op)
  local hi = band(op, 0xf0)
  if hi == 0x20 then
    if band(op, 0xf0) ~= band(self.prevOp, 0xf0) then self.acc = band(op, 0xf) end
    return 0
  elseif hi == 0x30 then
    local v = band(op, 0xf); self.acc = self.acc + v
    self.skip = (v ~= 10 and band(self.acc, 0x10) ~= 0); self.acc = band(self.acc, 0xf); return 0
  elseif hi == 0x40 then
    self.bm = bor(band(self.bm, 4), band(op, 3))
    self.bl = bor(band(rshift(op, 2), 3), (band(op, 0xc) ~= 0) and 0xc or 0); return 0
  elseif hi == 0x70 then
    local p = self.param; self:branch(band(rshift(p, 6), 3), band(op, 0xf), band(p, 0x3f)); return 0
  elseif op >= 0x80 and op < 0xc0 then
    self.pc = bor(band(self.pc, 0xfc0), band(op, 0x3f)); return 0
  elseif op >= 0xc0 then
    self:push(); local idx = self.rom[band(op, 0x3f)]
    self:branch(band(rshift(idx, 6), 3), 4, band(idx, 0x3f)); return 1
  end
  local q, bitm = band(op, 0xfc), lshift(1, band(op, 3))
  if q == 0x04 then self:ramW(band(self:ramR(), bit.bnot(bitm))); return 0
  elseif q == 0x0c then self:ramW(bor(self:ramR(), bitm)); return 0
  elseif q == 0x10 then self:exc(op); return 0
  elseif q == 0x14 then self:exc(op); self:incb(); return 0
  elseif q == 0x18 then self.acc = self:ramR(); self.bm = bxor(self.bm, band(op, 3)); return 0
  elseif q == 0x1c then self:exc(op); self:decb(); return 0
  elseif q == 0x54 then self.skip = band(self:ramR(), bitm) ~= 0; return 0
  elseif q == 0x68 then
    local p = self.param; self:push(); self:branch(band(rshift(p, 6), 3), band(op, 3), band(p, 0x3f)); return 0
  end
  if op == 0x00 then local cc = band(self.acc, 1); self.acc = bor(rshift(self.acc, 1), lshift(self.c, 3)); self.c = cc
  elseif op == 0x01 then self.acc = band(rshift(self.div, 11), 0xf)
  elseif op == 0x02 then
  elseif op == 0x03 then self.pc = bor(band(self.prevPc, bit.bnot(0xf)), self.acc); self.pc = band(self.pc, 0xfff)
  elseif op == 0x08 then self.acc = band(self.acc + self:ramR(), 0xf)
  elseif op == 0x09 then
    self.acc = self.acc + self:ramR() + self.c; self.c = band(rshift(self.acc, 4), 1)
    self.skip = (self.c == 1); self.acc = band(self.acc, 0xf)
  elseif op == 0x0a then self.acc = bxor(self.acc, 0xf)
  elseif op == 0x0b then local a = self.acc; self.acc = self.bl; self.bl = a
  elseif op == 0x50 then self.acc = self:readK()
  elseif op == 0x51 then self.skip = self.b ~= 0
  elseif op == 0x52 then self.skip = (self.c == 0)
  elseif op == 0x53 then self.skip = (self.acc == self:ramR())
  elseif op == 0x58 then self.skip = not self.k1s; self.k1s = false
  elseif op == 0x59 then self.l = self.acc
  elseif op == 0x5a then self.skip = (self.acc == 0)
  elseif op == 0x5b then self.skip = (self.acc == self.bl)
  elseif op == 0x5c then self.x = self.acc
  elseif op == 0x5d then self.halt = true
  elseif op == 0x5e then self.skip = self.ba ~= 0
  elseif op == 0x5f then self.bl = band(self.param, 0xf); self.bm = rshift(band(self.param, 0x7f), 4)
  elseif op == 0x60 then
    local p = self.param
    if p == 0x30 then self.melRd = band(self.melRd, 2)
    elseif p == 0x31 then self.melRd = bor(self.melRd, 1)
    elseif p == 0x32 then self.skip = band(self.melRd, 2) ~= 0; self.melRd = band(self.melRd, 1)
    elseif p == 0x33 then self.y = self.acc
    elseif p == 0x34 then self.bc = (self.c ~= 0) and 1 or 0
    elseif p == 0x35 then self.bp = self.acc
    elseif p == 0x36 then self.clkDiv = 2
    elseif p == 0x37 then self.clkDiv = 4 end
  elseif op == 0x61 then self.melAddr = self.param; self.melStep = 0
  elseif op == 0x62 then self.w = band(lshift(self.w, 1), 0xff)
  elseif op == 0x63 then self.w = band(bor(lshift(self.w, 1), 1), 0xff)
  elseif op == 0x64 then self:incb()
  elseif op == 0x65 then self.div = band(self.div, 0x7f00)
  elseif op == 0x66 then self.c = 0
  elseif op == 0x67 then self.c = 1
  elseif op == 0x6c then self:decb()
  elseif op == 0x6d then self.s = self.w
  elseif op == 0x6e then self:pop()
  elseif op == 0x6f then self:pop(); self.skip = true
  end
  return 0
end

-- état des segments : out[x*64 + y*4 + z] = 0/1
function M:lcd(out)
  local on = (self.bc == 0) and band(self.bp, 1) == 1
  for z = 0, 3 do
    for y = 0, 15 do
      out[y * 4 + z] = on and band(rshift(self.ram[0x60 + y], z), 1) or 0
      out[64 + y * 4 + z] = on and band(rshift(self.ram[0x70 + y], z), 1) or 0
    end
    local blink = (band(self.div, 0x4000) ~= 0) and self.y or 0
    local bs = bor(band(rshift(band(self.l, bit.bnot(blink)), z), 1), band(rshift(self.x * 2, z), 2))
    out[128 + z] = on and band(bs, 1) or 0
    out[132 + z] = on and band(rshift(bs, 1), 1) or 0
  end
  return out
end

return M
