-- DK Jr. Panorama — version console (Anbernic RG35XX SP / PortMaster, LÖVE 11)
local SM511 = require("sm511")
local LAY = require("layout")

local SR = 32768                 -- 1 échantillon audio = 1 tick de l'horloge de la console
local cpu
local seg = {}
for i = 0, 191 do seg[i] = 0 end

-- réglages (conservés entre deux lancements)
local opt = { gfx = "hd", snd = "orig", mute = false }
local PR = require("progress")
local SKINS = PR.ORDER
local SKNAME = { orig = "Original", hd = "Remake HD", lcdhd = "Origine embellie", hiver = "Hiver", automne = "Automne", halloween = "Halloween", noel = "Noel", dark = "Monde Dark" }
local function saveOpt()
  love.filesystem.write("settings.txt", opt.gfx .. "\n" .. opt.snd .. "\n" .. (opt.mute and "1" or "0") .. "\n")
end
local function loadOpt()
  local s = love.filesystem.read("settings.txt")
  if not s then return end
  local a, b, c = s:match("([^\n]*)\n([^\n]*)\n([^\n]*)")
  if SKNAME[a] then opt.gfx = a end
  -- au lancement : toujours le son d'origine (bip)
  opt.snd = "orig"
  opt.mute = (c == "1")
end

-- ---------------------------------------------------------------- images
local IMG = {}
local BG = {}
local function idxOf(t)
  local x, y, z = t:match("(%d+)%.(%d+)%.(%d+)")
  return tonumber(x) * 64 + tonumber(y) * 4 + tonumber(z)
end
local function loadSet(name)
  if IMG[name] then return end
  IMG[name] = {}
  for i, v in pairs(LAY[name]) do
    local im = love.graphics.newImage("assets/" .. name .. "/" .. v[1])
    im:setFilter("linear", "linear")
    IMG[name][i] = { im, v[2], v[3] }
  end
  BG[name] = love.graphics.newImage("assets/" .. name .. "/bg.jpg"); BG[name]:setFilter("linear", "linear")
end

-- ---------------------------------------------------------------- commandes
local INPUTS = {
  time = { 2, 1 }, gameb = { 2, 2 }, gamea = { 2, 4 }, alarm = { 2, 8 },
  jump = { 0, 15 },
  right = { 1, 1 }, up = { 1, 2 }, left = { 1, 4 }, down = { 1, 8 },
}
local held = {}
local function applyInputs()
  for i = 0, 7 do cpu.inputs[i] = 0 end
  for k, d in pairs(INPUTS) do
    if held[k] then cpu.inputs[d[1]] = bit.bor(cpu.inputs[d[1]], d[2]) end
  end
end
local toast, toastT = "", 0
local function say(s) toast = s; toastT = 2.0 end
local lastToggle = {}
local function action(name, down)
  if video then if down and (name == "jump" or name == "gamea") then skipVideo = true end return end
  if down and (name == "acl" or name == "gfx" or name == "snd" or name == "mute" or name == "final" or name == "tro") then
    local now = love.timer and love.timer.getTime() or 0
    if lastToggle[name] and now - lastToggle[name] < 0.25 then return end   -- évite le double déclenchement manette + gptokeyb
    lastToggle[name] = now
  end
  if name == "acl" then if down then cpu:reset(); say("ACL") end return end
  if name == "gfx" then
    if down then
      local k = 1; for j, n in ipairs(SKINS) do if n == opt.gfx then k = j end end
      repeat k = k % #SKINS + 1 until PR.unlocked(SKINS[k])
      opt.gfx = SKINS[k]; loadSet(opt.gfx); saveOpt(); PR.usedSkin(opt.gfx)
      say("Graphismes : " .. SKNAME[opt.gfx]) end
    return
  end
  if name == "snd" then
    if down then opt.snd = (opt.snd == "sym") and "orig" or "sym"; saveOpt()
      say(opt.snd == "sym" and "Son : Symphonique HD" or "Son : Original (bip)") end
    return
  end
  if name == "mute" then if down then opt.mute = not opt.mute; saveOpt(); say(opt.mute and "Son coupé" or "Son activé") end return end
  if name == "tro" then if down then res = nil; showTro = (not showTro) and "tro" or (showTro == "tro" and "top" or false) end return end
  if name == "final" then
    if down then
      if not PR.unlocked("dark") then say("Defi final : debloque d'abord le Monde Dark (800 pts)")
      else PR.final = not PR.final
        if PR.final then opt.gfx = "dark"; loadSet("dark"); cpu:reset(); finalStart = 0.6; say("DEFI FINAL : 980 pts ! Lance-pierre puis parapluie")
        else cpu:reset(); say("Defi final termine") end end
    end
    return
  end
  if res and down and (name == "jump" or name == "gamea" or name == "gameb") then res = nil; return end
  if name == "gamea" or name == "gameb" then if down and showTro then showTro = false end end
  if name == "quit" then if down then love.event.quit() end return end
  if INPUTS[name] then held[name] = down; applyInputs() end
end

-- clavier (gptokeyb transforme les boutons de la console en touches)
local KEYS = {
  up = "up", down = "down", left = "left", right = "right",
  space = "jump", x = "jump", z = "jump", lctrl = "jump",
  ["return"] = "gamea", ["1"] = "gamea", backspace = "gameb", ["2"] = "gameb",
  h = "time", a = "time", l = "alarm", s = "alarm",
  v = "gfx", o = "snd", m = "mute", r = "acl", escape = "quit", t = "tro", f = "final",
}
function love.keypressed(k, sc, rep) if not rep and KEYS[k] then action(KEYS[k], true) end end
function love.keyreleased(k) if KEYS[k] then action(KEYS[k], false) end end

-- manette directe (si gptokeyb ne prend pas la main)
local PAD = {
  dpup = "up", dpdown = "down", dpleft = "left", dpright = "right",
  a = "jump", b = "jump", x = "time", y = "alarm",
  start = "gamea", back = "gameb",
  leftshoulder = "gfx", rightshoulder = "snd", guide = "quit",
}
local padHeld = {}
function love.gamepadpressed(j, b)
  padHeld[b] = true
  if padHeld.start and padHeld.back then love.event.quit() return end
  if PAD[b] then action(PAD[b], true) end
end
function love.gamepadreleased(j, b) padHeld[b] = nil; if PAD[b] then action(PAD[b], false) end end
function love.gamepadaxis(j, axis, v)
  if axis == "triggerleft" then if v > 0.5 and not padHeld.tl then padHeld.tl = true; action("tro", true) elseif v < 0.3 then padHeld.tl = nil end end
  if axis == "triggerright" then if v > 0.5 and not padHeld.tr then padHeld.tr = true; action("final", true) elseif v < 0.3 then padHeld.tr = nil end end
  local function st(k, on) if (padHeld["ax_" .. k] or false) ~= on then padHeld["ax_" .. k] = on or nil; action(k, on) end end
  if axis == "leftx" then st("left", v < -0.5); st("right", v > 0.5)
  elseif axis == "lefty" then st("up", v < -0.5); st("down", v > 0.5) end
end

-- ---------------------------------------------------------------- son
local src, BUF = nil, 512
local sd
-- bip d'origine (filtré)
local lp1, lp2, hp, prev, gain = 0, 0, 0, 0, 0
local aLP = 1 - math.exp(-2 * math.pi * 4200 / SR)
local dc = 1 - 2 * math.pi * 15 / SR
-- moteur symphonique
local env, noteOn, lastAddr, nf, age = 0, false, -1, 440, 0
local ph = { 0, 0, 0, 0, 0, 0 }
local vib, slp1, slp2 = 0, 0, 0
local atk = 1 - math.exp(-1 / (0.010 * SR))
local rel = 1 - math.exp(-1 / (0.075 * SR))
local dec = 1 - math.exp(-1 / (0.35 * SR))
local function mkbuf(n) local t = { b = {}, i = 0, n = n, lp = 0 }; for k = 0, n - 1 do t.b[k] = 0 end; return t end
local sc = SR / 44100
local combs = { mkbuf(math.floor(1116 * sc)), mkbuf(math.floor(1188 * sc)), mkbuf(math.floor(1277 * sc)), mkbuf(math.floor(1356 * sc)) }
local aps = { mkbuf(math.floor(556 * sc)), mkbuf(math.floor(441 * sc)) }
local det = { 1, 1.0042, 0.9961 }
local LUT = SM511.LUT
local sin, floor, tanh2 = math.sin, math.floor, nil
local function tanh(x) local e = math.exp(2 * x); return (e - 1) / (e + 1) end
local TAU = 2 * math.pi

local function symph()
  local cmd = bit.band(cpu.mel[bit.band(cpu.melAddr, 0xff)], 0x3f)
  local t = bit.band(cmd, 0xf)
  local on = bit.band(cpu.melRd, 1) == 1 and t > 1 and t < 14
  if on then
    local sh = bit.band(bit.rshift(bit.bnot(cmd), 4), 1)
    local P = bit.lshift(LUT[t] + LUT[16 + t] + LUT[32 + t] + LUT[48 + t], sh)
    local fT = 65536 / P
    if (not noteOn) or cpu.melAddr ~= lastAddr then
      if (not noteOn) or math.abs(fT - nf) > 1 then env = math.min(env, 0.25); age = 0 end
      nf = fT; lastAddr = cpu.melAddr
    end
    noteOn = true
  else noteOn = false end
  if noteOn then
    local early = age < 0.03 * SR
    env = env + ((early and 1 or 0.78) - env) * (early and atk or dec); age = age + 1
  else env = env - env * rel end
  if env < 1e-5 and not noteOn then
    -- silence : on laisse seulement la réverbération s'éteindre
  end
  vib = vib + 5.3 / SR
  local vb = 1 + 0.0035 * sin(TAU * vib) * math.min(1, age / (0.15 * SR))
  local f = nf / 2 * vb
  local str = 0
  for k = 1, 3 do local p = ph[k] + f * det[k] / SR; p = p - floor(p); ph[k] = p; str = str + 2 * p - 1 end
  str = str / 3
  local fc = 1 - math.exp(-TAU * math.min(3200, f * 5) / SR)
  slp1 = slp1 + (str - slp1) * fc; slp2 = slp2 + (slp1 - slp2) * fc
  ph[4] = ph[4] + nf * vb / SR; ph[4] = ph[4] - floor(ph[4])
  ph[5] = ph[5] + f / 2 / SR; ph[5] = ph[5] - floor(ph[5])
  ph[6] = ph[6] + nf * 2 / SR; ph[6] = ph[6] - floor(ph[6])
  local bell = sin(TAU * ph[6]) * math.exp(-age / (0.08 * SR))
  local dry = env * (0.55 * slp2 + 0.30 * sin(TAU * ph[4]) + 0.22 * sin(TAU * ph[5]) + 0.10 * bell)
  local wet = 0
  for k = 1, 4 do
    local cb = combs[k]; local y = cb.b[cb.i]
    cb.lp = y * 0.75 + cb.lp * 0.25; cb.b[cb.i] = dry + cb.lp * 0.62
    cb.i = cb.i + 1; if cb.i >= cb.n then cb.i = 0 end
    wet = wet + y
  end
  wet = wet * 0.25
  for k = 1, 2 do
    local ap = aps[k]; local bo = ap.b[ap.i]; local y = -wet + bo
    ap.b[ap.i] = wet + bo * 0.5; ap.i = ap.i + 1; if ap.i >= ap.n then ap.i = 0 end
    wet = y
  end
  return tanh((dry * 0.9 + wet * 0.14) * 1.4) * 0.42
end

local spAcc = 0
local function sample()
  cpu:tick()
  if opt.gfx == "dark" then spAcc = spAcc + 0.25; if spAcc >= 1 then spAcc = spAcc - 1; cpu:tick() end end
  local s = cpu.r
  lp1 = lp1 + (s - lp1) * aLP; lp2 = lp2 + (lp1 - lp2) * aLP
  hp = dc * (hp + lp2 - prev); prev = lp2
  gain = gain + (((opt.mute or video) and 0 or 1) - gain) * 0.002
  local v
  if opt.snd == "sym" then v = symph() else v = hp * 0.26 end
  return v * gain
end

local produced, clock0 = 0, nil
local function pumpAudio()
  if not src then return false end
  local n = 0
  while src:getFreeBufferCount() > 0 and n < 8 do
    for i = 0, BUF - 1 do
      local v = sample()
      if v > 1 then v = 1 elseif v < -1 then v = -1 end
      sd:setSample(i, v)
    end
    src:queue(sd); n = n + 1; produced = produced + BUF
  end
  if not src:isPlaying() then src:play() end
  return true
end

-- ---------------------------------------------------------------- démarrage
local scale, ox, oy = 1, 0, 0
local fontS, fontM
function love.load()
  love.mouse.setVisible(false)
  loadOpt()
  cpu = SM511.new(love.filesystem.read("cj-93.program"), love.filesystem.read("cj-93.melody"))
  for i = 1, 4096 do cpu:tick() end
  cpu:reset()                       -- comme une vraie console : ACL à la mise sous tension
  loadSet(opt.gfx)
  for k = 1, 30 do FF[k] = { math.random() * 640, 90 + math.random() * (LAY.H - 90), 0, math.random() * 6.28, 0.6 + math.random() * 1.4 } end
  for k = 1, 30 do SKYS[k] = { 357 + math.random() * 137, math.random() * 76, 0.5 + math.random() * 0.8, math.random() * 6.28, 1 + math.random() * 2.5 } end
  for k = 1, 90 do flakes[k] = { math.random() * 640, math.random() * LAY.H, 0.25 + math.random() * 0.7, 0.8 + math.random() * 1.6, math.random() * 6.28 } end
  fontS = love.graphics.newFont(13); fontM = love.graphics.newFont(18); fontBig = love.graphics.newFont(64)
  local ok, s = pcall(love.audio.newQueueableSource, SR, 16, 1, 4)
  if ok and s then src = s; sd = love.sound.newSoundData(BUF, SR, 16, 1) end
  local w, h = love.graphics.getDimensions()
  scale = math.min(w / 640, h / 480); ox = (w - 640 * scale) / 2; oy = (h - 480 * scale) / 2
  PR.load(say)
  if not PR.unlocked(opt.gfx) then opt.gfx = "hd"; loadSet("hd") end
  lavaMask = love.graphics.newImage("assets/dark/lava_mask.png")
  for k = 1, 45 do embers[k] = { math.random() * 640, LAY.H * (0.7 + math.random() * 0.3), 18 + math.random() * 40, 0.8 + math.random() * 1.6, math.random(), math.random() * 6 } end
  say("START : Game A  ·  SELECT : Game B")
end

local acc = 0
showTro = false; res = nil; video = nil; finalStart = 0; lavaMask = nil; embers = {}; boltT = 4; flash = 0; bolt = nil
local troT = 0
local function startVideo()
  local ok, v = pcall(love.graphics.newVideo, "assets/fin.ogv", { audio = false })
  if ok and v then video = v; video:play() else say("Video de fin introuvable") return end
  local ok2, m = pcall(love.audio.newSource, "assets/fin.ogg", "stream")
  if ok2 and m then finMusic = m; finMusic:play() end
end
local function endVideo()
  if video then video:pause(); video = nil end
  if finMusic then finMusic:stop(); finMusic = nil end
  cpu:reset(); finalStart = 0.6
end
flakes = {}
FF = {}; bats = {}; batT = 2; shoots = {}; shootT = 3; SKYS = {}
local LIGHTS = require("lights")
local LCOL = { {1, .25, .25}, {.3, 1, .45}, {1, .85, .25}, {.3, .75, 1}, {1, .5, .95} }
local tSnow = 0
function love.update(dt)
  local now = love.timer.getTime(); clock0 = clock0 or now
  local audio = pumpAudio()
  -- si la sortie son ne consomme rien (pilote absent), l'émulation avance quand même au bon rythme
  if audio and produced < (now - clock0) * SR - SR * 0.3 then
    local lag = math.min((now - clock0) * SR - produced, SR * 0.1)
    for i = 1, lag do sample() end
    produced = produced + lag
  end
  if not audio then
    -- pas de son : on cadence l'émulation sur l'horloge vidéo
    acc = acc + math.min(dt, 0.1) * SR
    while acc >= 1 do sample(); acc = acc - 1 end
  end
  if toastT > 0 then toastT = toastT - dt end
  -- écran calculé ici (score décalé en défi final), puis progression / trophées
  cpu:lcd(seg)
  if PR.final then PR.applyOffset(seg, 980) end
  if finalStart > 0 then finalStart = finalStart - dt; if finalStart <= 0 then action("gamea", true); gaT = 0.25 end end
  if gaT and gaT > 0 then gaT = gaT - dt; if gaT <= 0 then action("gamea", false) end end
  if not video then
    local r = PR.update(seg, opt.gfx, opt.snd == "sym")
    if r == "ending" then PR.realEnding(); startVideo() end
    if r == "over" and PR.final then say("Defi final : relance avec R2 (ou Game A pour une partie normale)") end
    if r == "over" and not PR.final then
      res = PR.finish(opt.gfx)
      local okq, QR = pcall(require, "qrencode")
      if okq then local ok, tab = QR.qrcode(res.url); if ok then res.qr = tab end end
    end
  elseif skipVideo or not video:isPlaying() then skipVideo = false; endVideo() end
  if troT > 0 then troT = troT - dt elseif #PR.queue > 0 then PR.cur = table.remove(PR.queue, 1); troT = 3.2 end
  tSnow = tSnow + dt
  if opt.gfx == "dark" then
    for _, e in ipairs(embers) do e[2] = e[2] - e[3] * dt; e[5] = e[5] + dt * 0.25; e[1] = e[1] + math.sin(tSnow * 2 + e[6]) * 0.3
      if e[2] < -4 or e[5] > 1 then e[2] = LAY.H * (0.72 + math.random() * 0.28); e[1] = math.random() * 640; e[5] = 0 end end
    boltT = boltT - dt
    if boltT <= 0 then boltT = 5 + math.random() * 7; flash = 1; bolt = {}; local x, y = 160 + math.random() * 384, 0
      while y < 110 + math.random() * 40 do bolt[#bolt + 1] = x; bolt[#bolt + 1] = y; x = x + (math.random() - 0.5) * 28; y = y + 7 + math.random() * 12 end end
    if flash > 0 then flash = flash - dt * (flash > 0.6 and 2.5 or 1.6); if flash < 0 then flash = 0; bolt = nil end end
  end
  if opt.gfx == "hiver" or opt.gfx == "noel" or opt.gfx == "automne" then
    local sp = opt.gfx == "automne" and 0.35 or 0.5
    for _, f in ipairs(flakes) do
      f[2] = f[2] + f[3] * 60 * dt * sp; f[1] = f[1] + math.sin(tSnow * 1.3 + f[5]) * 0.25
      if f[2] > LAY.H + 3 then f[2] = -3; f[1] = math.random() * 640 end
    end
  end
  if opt.gfx == "halloween" then
    for _, f in ipairs(FF) do
      f[1] = f[1] + math.sin(tSnow * 0.7 + f[4]) * 8 * dt; f[2] = f[2] + math.cos(tSnow * 0.5 + f[4]) * 6 * dt
      if f[1] < 0 then f[1] = 640 elseif f[1] > 640 then f[1] = 0 end
    end
    batT = batT - dt
    if batT <= 0 then
      batT = 3 + math.random() * 5
      local dir = math.random() < 0.5 and 1 or -1; local y0 = 20 + math.random() * 120
      for i = 1, math.random(1, 3) do bats[#bats + 1] = { dir > 0 and (-20 - i * 25) or (660 + i * 25), y0 + math.random(-15, 15), dir * (90 + math.random() * 40), 0.8 + math.random() * 0.5, math.random() * 6 } end
    end
    for i = #bats, 1, -1 do local b = bats[i]; b[1] = b[1] + b[3] * dt; if b[1] < -80 or b[1] > 720 then table.remove(bats, i) end end
  end
  if opt.gfx == "noel" then
    shootT = shootT - dt
    if shootT <= 0 then shootT = 4 + math.random() * 6; shoots[#shoots + 1] = { 360 + math.random() * 100, 4 + math.random() * 30, 0 } end
    for i = #shoots, 1, -1 do local s = shoots[i]; s[3] = s[3] + dt; s[1] = s[1] + 110 * dt; s[2] = s[2] + 45 * dt; if s[3] > 1.1 then table.remove(shoots, i) end end
  end
end

-- ---------------------------------------------------------------- affichage
local GY = 66                       -- position verticale de l'écran de jeu (640 x 348)

function love.draw()
  local g = love.graphics
  g.clear(0.03, 0.07, 0.05)
  g.push(); g.translate(ox, oy); g.scale(scale)
  -- bandeau haut
  g.setColor(0.85, 0.7, 0.37); g.setFont(fontM)
  g.print(PR.final and "DEFI FINAL - MONDE DARK" or "DONKEY KONG JR.", 14, 22)
  g.setColor(0.6, 0.75, 0.65); g.setFont(fontS)
  g.printf(SKNAME[opt.gfx] .. "  ·  " .. (opt.snd == "sym" and "Symphonique" or "Bip") .. (opt.mute and " (muet)" or ""), 0, 27, 626, "right")
  g.setScissor(ox, oy + GY * scale, 640 * scale, LAY.H * scale)
  local set = IMG[opt.gfx]
  g.setColor(1, 1, 1); g.draw(BG[opt.gfx], 0, GY)
  for i = 0, 191 do
    if seg[i] == 1 then local s = set[i]; if s then g.draw(s[1], s[2], GY + s[3]) end end
  end
  local T = tSnow
  if opt.gfx == "dark" then
    g.setBlendMode("add")
    if lavaMask then local a = 0.35 + 0.15 * math.sin(T * 2) + 0.1 * math.sin(T * 5.3); g.setColor(1, 0.55, 0.15, a); g.draw(lavaMask, 0, GY)
      g.setColor(1, 0.85, 0.4, 0.12 + 0.1 * math.sin(T * 3.1 + 1)); g.draw(lavaMask, 0, GY + 2 * math.sin(T * 4)) end
    for _, e in ipairs(embers) do local a = math.sin(math.pi * e[5]) * (0.6 + 0.4 * math.sin(e[6] + T * 6))
      if a > 0 then g.setColor(1, 0.45, 0.1, a * 0.5); g.circle("fill", e[1], GY + e[2], e[4] * 2.4); g.setColor(1, 0.9, 0.5, a); g.circle("fill", e[1], GY + e[2], e[4] * 0.8) end end
    if flash > 0 then g.setColor(1, 0.82, 0.75, flash * 0.35); g.rectangle("fill", 0, GY, 640, LAY.H)
      if bolt and #bolt >= 4 then g.setColor(1, 0.95, 0.92, math.min(1, flash * 1.5)); g.setLineWidth(2.5); local pts = {}; for i = 1, #bolt, 2 do pts[#pts + 1] = bolt[i]; pts[#pts + 1] = GY + bolt[i + 1] end; g.line(pts) end end
    g.setBlendMode("alpha")
  end
  if opt.gfx == "noel" then
    g.setBlendMode("add")
    for _, s in ipairs(SKYS) do local a = 0.3 + 0.7 * math.max(0, math.sin(T * s[5] + s[4])) ^ 3; g.setColor(1, 1, 1, a); g.circle("fill", s[1], GY + s[2], s[3]) end
    local a = 0.55 + 0.45 * math.sin(T * 1.6); g.setColor(1, 0.98, 0.85, 0.35 * a); g.circle("fill", 426, GY + 23, 12 + 3 * a); g.setColor(1, 1, 0.9, 0.6 * a); g.circle("fill", 426, GY + 23, 5)
    local step = math.floor(T * 1.4) % 3
    for i, p in ipairs(LIGHTS) do
      local grp = math.floor((p[1] + p[2]) / 11) % 3
      local on = (grp == step) and 1 or 0.25
      local c = LCOL[(i * 7) % 5 + 1]; local al = on * (0.7 + 0.3 * math.sin(T * 6 + i))
      if al > 0.1 then g.setColor(c[1], c[2], c[3], al * 0.45); g.circle("fill", p[1], GY + p[2], 4); g.setColor(1, 1, 0.95, al * 0.8); g.circle("fill", p[1], GY + p[2], 1.4) end
    end
    for _, s in ipairs(shoots) do local a = math.sin(math.pi * s[3] / 1.1); g.setColor(1, 1, 0.9, a); g.setLineWidth(1.5); g.line(s[1] - 38, GY + s[2] - 15, s[1], GY + s[2]); g.circle("fill", s[1], GY + s[2], 1.5) end
    g.setBlendMode("alpha")
  end
  if opt.gfx == "hiver" or opt.gfx == "noel" then
    g.setColor(1, 1, 1, 0.85)
    for _, f in ipairs(flakes) do g.circle("fill", f[1], GY + f[2], f[4]) end
  elseif opt.gfx == "automne" then
    local LC = { {.91, .45, .11}, {.79, .25, .1}, {.95, .66, .16}, {.66, .31, .12}, {.94, .75, .25} }
    for i, f in ipairs(flakes) do if i <= 40 then
      local c = LC[i % 5 + 1]; g.setColor(c[1], c[2], c[3], 0.95)
      g.push(); g.translate(f[1], GY + f[2]); g.rotate(T * (i % 3 - 1) * 1.5 + f[5] + math.sin(T + f[5]) * 0.8)
      g.ellipse("fill", 0, 0, f[4] * 2.6, f[4] * 1.2); g.setColor(0.3, 0.12, 0.04, 0.6); g.setLineWidth(1); g.line(-f[4] * 3, 0, f[4] * 2, 0); g.pop()
    end end
  elseif opt.gfx == "halloween" then
    g.setBlendMode("add")
    for _, f in ipairs(FF) do local a = math.max(0, math.sin(T * f[5] + f[4])) ^ 2
      if a > 0.03 then g.setColor(0.75, 1, 0.35, a * 0.35); g.circle("fill", f[1], GY + f[2], 5); g.setColor(0.95, 1, 0.6, a); g.circle("fill", f[1], GY + f[2], 1.5) end end
    g.setBlendMode("alpha")
    g.setColor(0.07, 0.04, 0.09)
    for _, b in ipairs(bats) do
      local x, y, s = b[1], GY + b[2] + math.sin(T * 2.2 + b[5]) * 8, 6 * b[4]; local wy = math.sin(T * 16 + b[5]) * s * 0.9
      g.polygon("fill", x, y, x - s * 1.3, y - s * 0.5 + wy * 0.4, x - s * 2.6, y - wy, x - s * 1.6, y + s * 0.4, x - s * 0.8, y + s * 0.4)
      g.polygon("fill", x, y, x + s * 1.3, y - s * 0.5 + wy * 0.4, x + s * 2.6, y - wy, x + s * 1.6, y + s * 0.4, x + s * 0.8, y + s * 0.4)
      g.ellipse("fill", x, y + s * 0.15, s * 0.45, s * 0.6)
    end
  end
  g.setColor(1, 1, 1)
  g.setScissor()
  -- cadre
  g.setColor(0.85, 0.7, 0.37); g.setLineWidth(2); g.rectangle("line", 0, GY - 1, 640, LAY.H + 2)
  -- aide en bas
  g.setColor(0.6, 0.75, 0.65); g.setFont(fontS)
  g.printf("A/B saut · X heure · Y alarme · L1 graphismes · R1 son · L2 trophees · R2 defi final · SEL+START quitter", 8, GY + LAY.H + 14, 624, "center")
  if toastT > 0 then
    local a = math.min(1, toastT * 2)
    g.setColor(0, 0, 0, 0.7 * a); g.rectangle("fill", 170, GY + LAY.H / 2 - 18, 300, 36, 8, 8)
    g.setColor(1, 0.9, 0.6, a); g.setFont(fontM); g.printf(toast, 170, GY + LAY.H / 2 - 11, 300, "center")
  end
  -- notification de trophée
  if troT > 0 and PR.cur then local t = PR.TROPHIES[PR.cur + 1]; local a = math.min(1, troT * 3, (3.2 - troT) * 4)
    g.setColor(0.05, 0.1, 0.06, 0.92 * a); g.rectangle("fill", 330, 6, 300, 44, 8, 8); g.setColor(0.85, 0.7, 0.37, a); g.rectangle("line", 330, 6, 300, 44, 8, 8)
    g.setFont(fontS); g.print("TROPHEE DEBLOQUE", 342, 10); g.setColor(1, 1, 1, a); g.print(t[1], 342, 28) end
  -- page des trophées (L2)
  if showTro == "tro" then
    g.setColor(0.02, 0.06, 0.04, 0.95); g.rectangle("fill", 0, 0, 640, 480)
    g.setColor(0.85, 0.7, 0.37); g.setFont(fontM); g.print("TROPHEES  " .. PR.count() .. " / " .. #PR.TROPHIES, 14, 10)
    g.setFont(fontS)
    for i, t in ipairs(PR.TROPHIES) do
      local col = (i - 1) % 2; local row = math.floor((i - 1) / 2); local x, y = 14 + col * 316, 40 + row * 27
      local own = PR.has(i - 1); local secret = t[3] == "S" and not own
      local tc = ({ F = {0.77, 0.55, 0.31}, M = {0.79, 0.81, 0.84}, D = {0.95, 0.79, 0.3}, S = {0.72, 0.55, 1} })[t[3]]
      g.setColor(tc[1], tc[2], tc[3], own and 1 or 0.35); g.circle("fill", x + 6, y + 8, 5)
      g.setColor(1, 1, 1, own and 1 or 0.4); g.print(secret and "???" or t[1], x + 16, y)
      g.setColor(0.6, 0.75, 0.65, own and 0.9 or 0.35); g.print(secret and "Un code secret..." or t[2], x + 16, y + 12)
    end
    g.setColor(0.6, 0.75, 0.65); g.printf("L2 : classement", 0, 462, 640, "center")
  end
  -- classement en ligne (L2 une 2e fois) : QR code vers la page du classement
  if showTro == "top" then
    if not lbQR then local okq, QR = pcall(require, "qrencode"); if okq then local ok, tab = QR.qrcode(PR.LB); if ok then lbQR = tab end end end
    g.setColor(0.02, 0.06, 0.04, 0.96); g.rectangle("fill", 0, 0, 640, 480)
    g.setColor(0.85, 0.7, 0.37); g.setFont(fontM); g.printf("CLASSEMENT EN LIGNE", 0, 16, 640, "center")
    if lbQR then local n = #lbQR; local cs = math.floor(330 / (n + 8)); local sz = cs * (n + 8); local x0, y0 = (640 - sz) / 2, 52
      g.setColor(1, 1, 1); g.rectangle("fill", x0, y0, sz, sz, 6, 6); g.setColor(0, 0, 0)
      for x = 1, n do for y = 1, n do if lbQR[x][y] > 0 then g.rectangle("fill", x0 + (x + 3) * cs, y0 + (y + 3) * cs, cs, cs) end end end
    end
    g.setFont(fontS); g.setColor(0.8, 0.85, 0.8)
    g.printf("Scanne ce QR code avec ton telephone pour voir le classement de tous les joueurs et leurs trophees.", 60, 400, 520, "center")
    g.setColor(0.6, 0.75, 0.65); g.printf("L2 pour fermer", 0, 456, 640, "center")
  end
  -- écran de fin de partie : score + QR code pour s'inscrire au classement en ligne
  if res then
    g.setColor(0.02, 0.06, 0.04, 0.95); g.rectangle("fill", 0, 0, 640, 480)
    g.setColor(0.85, 0.7, 0.37); g.setFont(fontM); g.printf("PARTIE TERMINEE", 0, 14, 640, "center")
    g.setColor(0.08, 0.1, 0.08); g.rectangle("fill", 40, 90, 230, 130, 10, 10); g.setColor(0.85, 0.7, 0.37); g.rectangle("line", 40, 90, 230, 130, 10, 10)
    g.setColor(1, 0.36, 0.25); g.setFont(fontBig or fontM); g.printf(string.format("%03d", res.score), 40, 112, 230, "center")
    g.setFont(fontS); g.setColor(1, 0.55, 0.45); g.printf("GAME " .. res.mode, 40, 190, 230, "center")
    g.setColor(0.8, 0.85, 0.8); g.printf(res.n .. (res.n > 1 and " trophees" or " trophee") .. " cette partie", 40, 236, 230, "center")
    if res.qr then local n = #res.qr; local cs = math.floor(300 / (n + 8)); local sz = cs * (n + 8); local x0, y0 = 600 - sz, 60
      g.setColor(1, 1, 1); g.rectangle("fill", x0, y0, sz, sz, 6, 6); g.setColor(0, 0, 0)
      for x = 1, n do for y = 1, n do if res.qr[x][y] > 0 then g.rectangle("fill", x0 + (x + 3) * cs, y0 + (y + 3) * cs, cs, cs) end end end
    end
    g.setFont(fontS); g.setColor(0.8, 0.85, 0.8)
    g.printf("Scanne le QR code avec ton telephone pour enregistrer ton score et tes trophees dans le classement en ligne.", 40, 380, 560, "center")
    g.setColor(0.6, 0.75, 0.65); g.printf("A ou START : continuer   -   L2 : trophees / classement", 0, 446, 640, "center")
  end
  -- vidéo de fin
  if video then g.setColor(0, 0, 0); g.rectangle("fill", 0, 0, 640, 480); g.setColor(1, 1, 1); g.draw(video, 0, 60, 0, 640 / video:getWidth(), 360 / video:getHeight()) end
  g.pop()
end
