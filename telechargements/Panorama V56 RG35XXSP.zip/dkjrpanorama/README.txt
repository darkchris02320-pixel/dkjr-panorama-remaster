DK Jr. Panorama — version console (usage personnel)

Commandes :
  START        Game A
  SELECT       Game B
  Croix        déplacer Junior
  A / B        sauter / attraper
  X            heure
  Y            alarme
  L1           graphismes : Remake HD / Original
  R1           son : Symphonique HD / Original (bip)
  L2           ACL (remise à zéro)
  R2           couper le son
  SELECT+START quitter
