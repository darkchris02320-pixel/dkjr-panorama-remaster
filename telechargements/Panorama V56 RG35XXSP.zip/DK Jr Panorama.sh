#!/bin/bash
# DK Jr. Panorama — port PortMaster (LÖVE 11.5)

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt
[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
get_controls

GAMEDIR="/$directory/ports/dkjrpanorama"
CONFDIR="$GAMEDIR/conf"
mkdir -p "$CONFDIR"
cd "$GAMEDIR"
> "$GAMEDIR/log.txt" && exec > >(tee "$GAMEDIR/log.txt") 2>&1

export XDG_DATA_HOME="$CONFDIR"
export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"

# Moteur LÖVE 11.5 fourni par PortMaster
runtime="love_11.5"
echo "controlfolder=$controlfolder  directory=$directory  CFW=$CFW_NAME  DEVICE=$DEVICE_NAME"
if [ ! -f "$controlfolder/runtimes/$runtime/love.txt" ]; then
  echo "runtime $runtime absent : tentative de telechargement"
  if [ -f "$controlfolder/harbourmaster" ]; then
    $ESUDO $controlfolder/harbourmaster --quiet --no-check runtime_check "${runtime}.squashfs"
  fi
fi
if [ ! -f "$controlfolder/runtimes/$runtime/love.txt" ]; then
  echo "ERREUR : $controlfolder/runtimes/$runtime/love.txt introuvable"
  ls -la "$controlfolder/runtimes" "$controlfolder/libs" 2>&1 | head -50
  pm_message "Moteur LOVE 11.5 manquant : PortMaster > Options > Runtime Manager > love_11.5"
  sleep 10
  pm_finish
  exit 1
fi
source "$controlfolder/runtimes/$runtime/love.txt"
echo "LOVE_RUN=$LOVE_RUN  LOVE_BINARY=$LOVE_BINARY"

$GPTOKEYB "$LOVE_GPTK" -c "$GAMEDIR/dkjrpanorama.gptk" &
pm_platform_helper "$LOVE_BINARY"
$LOVE_RUN "$GAMEDIR/gamedata"

pm_finish
